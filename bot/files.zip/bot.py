#!/usr/bin/env python3
"""
Главен Telegram бот:
  • Ръчно генериране на статии по тема
  • Автоматично следене на блога → одобрение → публикуване
"""

import os
import logging
import asyncio
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    Application, CommandHandler, MessageHandler,
    CallbackQueryHandler, ContextTypes, ConversationHandler, filters
)
import anthropic
from monitor import monitor_loop, build_full_text, get_first_image
from publisher import publish_to_platforms, PUBLISHERS
from ai_adapter import adapt_for_all_platforms

logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    level=logging.INFO
)
logger = logging.getLogger(__name__)

ALLOWED_USER_ID = int(os.environ.get("TELEGRAM_ALLOWED_USER_ID", "0"))
BLOG_BASE_URL = os.environ.get("BLOG_BASE_URL", "https://eng.d-dimitrov.eu")

CHOOSING_TYPE, ENTERING_TOPIC, REVIEWING, CHOOSING_PLATFORMS = range(4)
pending_approvals: dict = {}


def is_authorized(update: Update) -> bool:
    uid = update.effective_user.id if update.effective_user else 0
    return ALLOWED_USER_ID == 0 or uid == ALLOWED_USER_ID


# ─── Blog monitor callback ──────────────────────────────────────────────────

async def on_new_blog_post(article: dict, app: Application):
    logger.info(f"📬 Нова статия: {article['title']}")
    article_url = f"{BLOG_BASE_URL}/article/{article['id']}"
    image_url = get_first_image(article)

    try:
        adapted = await asyncio.get_event_loop().run_in_executor(
            None, adapt_for_all_platforms, article, article_url
        )
    except Exception as e:
        adapted = {p: build_full_text(article) for p in ["facebook", "instagram", "twitter", "linkedin"]}
        logger.error(f"AI адаптация неуспешна: {e}")

    preview = build_full_text(article)[:600]
    msg_text = (
        f"🆕 *Нова статия в блога!*\n\n"
        f"📌 *{article['title']}*\n\n"
        f"{preview}{'...' if len(build_full_text(article)) > 600 else ''}\n\n"
        f"🔗 {article_url}"
    )

    keyboard = [
        [
            InlineKeyboardButton("📘 Facebook", callback_data=f"blog_pub:facebook:{article['id']}"),
            InlineKeyboardButton("📸 Instagram", callback_data=f"blog_pub:instagram:{article['id']}"),
        ],
        [
            InlineKeyboardButton("🐦 Twitter/X", callback_data=f"blog_pub:twitter:{article['id']}"),
            InlineKeyboardButton("💼 LinkedIn", callback_data=f"blog_pub:linkedin:{article['id']}"),
        ],
        [InlineKeyboardButton("🌐 Всички платформи", callback_data=f"blog_pub:all:{article['id']}")],
        [InlineKeyboardButton("👀 Виж адаптираните текстове", callback_data=f"blog_preview:{article['id']}")],
        [InlineKeyboardButton("❌ Пропусни", callback_data=f"blog_skip:{article['id']}")],
    ]

    await app.bot.send_message(
        chat_id=ALLOWED_USER_ID,
        text=msg_text,
        parse_mode="Markdown",
        reply_markup=InlineKeyboardMarkup(keyboard)
    )

    pending_approvals[article["id"]] = {
        "article": article,
        "adapted": adapted,
        "image_url": image_url,
        "article_url": article_url,
    }


async def blog_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    parts = query.data.split(":")

    if parts[0] == "blog_preview":
        article_id = int(parts[1])
        pending = pending_approvals.get(article_id)
        if not pending:
            await query.edit_message_text("❌ Данните вече не са налични.")
            return
        adapted = pending["adapted"]
        preview_text = ""
        for platform, text in adapted.items():
            emoji = PUBLISHERS[platform][1]
            name = PUBLISHERS[platform][0]
            preview_text += f"\n\n{emoji} *{name}:*\n{text[:350]}{'...' if len(text) > 350 else ''}"
        await query.message.reply_text(
            f"📋 *Адаптирани текстове:*{preview_text}",
            parse_mode="Markdown"
        )
        return

    if parts[0] == "blog_skip":
        await query.edit_message_text("⏭️ Пропусната.")
        return

    if parts[0] == "blog_pub":
        platform_key = parts[1]
        article_id = int(parts[2])
        pending = pending_approvals.get(article_id)
        if not pending:
            await query.edit_message_text("❌ Вече публикувана или изтекла.")
            return

        platform_map = {
            "facebook": ["facebook"], "instagram": ["instagram"],
            "twitter": ["twitter"], "linkedin": ["linkedin"],
            "all": ["facebook", "instagram", "twitter", "linkedin"],
        }
        platforms = platform_map.get(platform_key, [])
        adapted = pending["adapted"]
        image_url = pending["image_url"]

        await query.edit_message_text("⏳ Публикувам...")

        lines = []
        for p in platforms:
            text = adapted.get(p, build_full_text(pending["article"]))
            results = await publish_to_platforms([p], text, image_url)
            r = results[p]
            status = "✅ Публикувано" if r["ok"] else f"❌ {r['error']}"
            lines.append(f"{r['emoji']} {r['name']}: {status}")

        await query.message.reply_text(
            "📊 *Резултати:*\n\n" + "\n".join(lines),
            parse_mode="Markdown"
        )
        if platform_key == "all":
            pending_approvals.pop(article_id, None)


# ─── Ръчно генериране ──────────────────────────────────────────────────────

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not is_authorized(update):
        return ConversationHandler.END
    keyboard = [
        [InlineKeyboardButton("📝 Блог статия (дълга)", callback_data="long")],
        [InlineKeyboardButton("⚡ Кратък пост", callback_data="short")],
        [InlineKeyboardButton("📡 Статус мониторинг", callback_data="monitor_status")],
    ]
    await update.message.reply_text(
        "👋 Здравей! Какво правим?",
        reply_markup=InlineKeyboardMarkup(keyboard)
    )
    return CHOOSING_TYPE


async def choose_type(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    query = update.callback_query
    await query.answer()
    if query.data == "monitor_status":
        from monitor import CHECK_INTERVAL, BLOG_API_URL
        await query.edit_message_text(
            f"📡 *Мониторинг:*\n\n🟢 Активен\n🔗 `{BLOG_API_URL}`\n⏱️ Всеки {CHECK_INTERVAL//60} мин",
            parse_mode="Markdown"
        )
        return ConversationHandler.END
    context.user_data["article_type"] = query.data
    await query.edit_message_text(
        f"✅ {'Блог статия' if query.data == 'long' else 'Кратък пост'}\n\n📌 Напиши темата:"
    )
    return ENTERING_TOPIC


async def enter_topic(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not is_authorized(update):
        return ConversationHandler.END
    topic = update.message.text
    context.user_data["topic"] = topic
    article_type = context.user_data.get("article_type", "short")
    await update.message.reply_text("⏳ Генерирам с AI...")
    try:
        client = anthropic.Anthropic(api_key=os.environ["ANTHROPIC_API_KEY"])
        system = (
            "Ти си опитен блогър. Пишеш на български. Блог статия 600-900 думи с въведение, параграфи и заключение."
            if article_type == "long" else
            "Ти си мениджър на социални мрежи. Пишеш на български. Кратък пост 150-250 думи с емоджи и хаштагове."
        )
        message = await asyncio.get_event_loop().run_in_executor(
            None,
            lambda: client.messages.create(
                model="claude-opus-4-6", max_tokens=2000, system=system,
                messages=[{"role": "user", "content": f"Напиши за тема: {topic}"}]
            )
        )
        text = message.content[0].text
        context.user_data["manual_text"] = text
        for i in range(0, len(text), 4000):
            await update.message.reply_text(text[i:i+4000])
        keyboard = [
            [InlineKeyboardButton("✅ Публикувай", callback_data="manual_publish"),
             InlineKeyboardButton("🔄 Пак", callback_data="regenerate")],
            [InlineKeyboardButton("❌ Откажи", callback_data="cancel")],
        ]
        await update.message.reply_text("Харесваш ли?", reply_markup=InlineKeyboardMarkup(keyboard))
        return REVIEWING
    except Exception as e:
        await update.message.reply_text(f"❌ Грешка: {e}")
        return ConversationHandler.END


async def review_article(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    query = update.callback_query
    await query.answer()
    if query.data == "cancel":
        await query.edit_message_text("❌ Отказано.")
        return ConversationHandler.END
    if query.data == "manual_publish":
        keyboard = [
            [InlineKeyboardButton("📘 Facebook", callback_data="mp:facebook"),
             InlineKeyboardButton("📸 Instagram", callback_data="mp:instagram")],
            [InlineKeyboardButton("🐦 Twitter/X", callback_data="mp:twitter"),
             InlineKeyboardButton("💼 LinkedIn", callback_data="mp:linkedin")],
            [InlineKeyboardButton("🌐 Всички", callback_data="mp:all")],
            [InlineKeyboardButton("❌ Откажи", callback_data="cancel")],
        ]
        await query.edit_message_text("📤 В кои платформи?", reply_markup=InlineKeyboardMarkup(keyboard))
        return CHOOSING_PLATFORMS
    if query.data == "regenerate":
        await query.edit_message_text("⏳ Регенерирам...")
        topic = context.user_data.get("topic", "")
        article_type = context.user_data.get("article_type", "short")
        try:
            client = anthropic.Anthropic(api_key=os.environ["ANTHROPIC_API_KEY"])
            system = (
                "Ти си опитен блогър. Пишеш на български. Нова различна версия на блог статия."
                if article_type == "long" else
                "Ти си мениджър на социални мрежи. Пишеш на български. Нова различна версия."
            )
            message = await asyncio.get_event_loop().run_in_executor(
                None,
                lambda: client.messages.create(
                    model="claude-opus-4-6", max_tokens=2000, system=system,
                    messages=[{"role": "user", "content": f"Напиши за тема: {topic}"}]
                )
            )
            text = message.content[0].text
            context.user_data["manual_text"] = text
            for i in range(0, len(text), 4000):
                await query.message.reply_text(text[i:i+4000])
            keyboard = [
                [InlineKeyboardButton("✅ Публикувай", callback_data="manual_publish"),
                 InlineKeyboardButton("🔄 Пак", callback_data="regenerate")],
                [InlineKeyboardButton("❌ Откажи", callback_data="cancel")],
            ]
            await query.message.reply_text("Харесваш ли тази версия?", reply_markup=InlineKeyboardMarkup(keyboard))
            return REVIEWING
        except Exception as e:
            await query.message.reply_text(f"❌ Грешка: {e}")
            return ConversationHandler.END


async def choose_platforms(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    query = update.callback_query
    await query.answer()
    if query.data == "cancel":
        await query.edit_message_text("❌ Отказано.")
        return ConversationHandler.END
    platform_key = query.data.split(":")[1]
    platform_map = {
        "facebook": ["facebook"], "instagram": ["instagram"],
        "twitter": ["twitter"], "linkedin": ["linkedin"],
        "all": ["facebook", "instagram", "twitter", "linkedin"],
    }
    platforms = platform_map.get(platform_key, [])
    text = context.user_data.get("manual_text", "")
    await query.edit_message_text("⏳ Публикувам...")
    lines = []
    for p in platforms:
        results = await publish_to_platforms([p], text, None)
        r = results[p]
        lines.append(f"{r['emoji']} {r['name']}: {'✅ Публикувано' if r['ok'] else '❌ ' + str(r['error'])}")
    await query.message.reply_text("📊 *Резултати:*\n\n" + "\n".join(lines), parse_mode="Markdown")
    return ConversationHandler.END


async def cancel(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    await update.message.reply_text("❌ Отказано.")
    return ConversationHandler.END


# ─── Main ──────────────────────────────────────────────────────────────────

def main():
    token = os.environ["TELEGRAM_BOT_TOKEN"]
    app = Application.builder().token(token).build()

    async def notify(article):
        await on_new_blog_post(article, app)

    async def start_monitor(app):
        asyncio.create_task(monitor_loop(notify))

    app.post_init = start_monitor

    conv = ConversationHandler(
        entry_points=[CommandHandler("start", start)],
        states={
            CHOOSING_TYPE: [CallbackQueryHandler(choose_type)],
            ENTERING_TOPIC: [MessageHandler(filters.TEXT & ~filters.COMMAND, enter_topic)],
            REVIEWING: [CallbackQueryHandler(review_article)],
            CHOOSING_PLATFORMS: [CallbackQueryHandler(choose_platforms)],
        },
        fallbacks=[CommandHandler("cancel", cancel)],
    )
    app.add_handler(conv)
    app.add_handler(CallbackQueryHandler(blog_callback, pattern=r"^(blog_pub|blog_preview|blog_skip):"))

    logger.info("🤖 Ботът е стартиран!")
    app.run_polling(allowed_updates=Update.ALL_TYPES)


if __name__ == "__main__":
    main()
